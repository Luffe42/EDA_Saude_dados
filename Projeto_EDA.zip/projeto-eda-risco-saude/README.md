# Análise Exploratória de Dados — Risco à Saúde

Projeto desenvolvido durante o curso **Análise de Dados com Python — SENAI**, utilizando Python para realizar uma Análise Exploratória de Dados (EDA).

## 🎯 Objetivo

Explorar uma base de dados com características demográficas e comportamentais, buscando identificar padrões e associações com a variável `risco_saude`, classificada em **alto** e **baixo** risco.

O projeto foi desenvolvido no **VS Code**, utilizando Python e bibliotecas de análise e visualização de dados.

## 🛠️ Tecnologias utilizadas

- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- VS Code

## 🔎 Etapas da análise

### 1. Carregamento dos dados
Leitura do arquivo CSV com `pandas.read_csv()`.

### 2. Inspeção e qualidade
Foram avaliados:

- primeiras linhas;
- estrutura do DataFrame;
- quantidade de linhas e colunas;
- tipos de dados;
- valores ausentes;
- registros duplicados;
- estatísticas descritivas.

### 3. Análise univariada
Foram exploradas as distribuições de:

- risco de saúde;
- idade;
- IMC;
- nível de exercício.

### 4. Análise bivariada
Foram investigadas associações entre o risco de saúde e:

- nível de exercício;
- horas de sono;
- tabagismo;
- consumo de álcool;
- consumo de açúcar;
- IMC;
- idade.

### 5. Correlação
Foi construída uma matriz de correlação entre as variáveis numéricas:

- idade;
- peso;
- altura;
- sono;
- IMC.

## 📊 Principais resultados

A base possui **5.000 registros e 12 variáveis**, sem valores ausentes e sem registros duplicados.

A distribuição da variável de interesse foi:

- **69,80%** classificados como alto risco;
- **30,20%** classificados como baixo risco.

Alguns padrões observados:

- Entre fumantes, **93,35%** foram classificados como alto risco.
- Entre consumidores de álcool, **84,11%** foram classificados como alto risco.
- No grupo com consumo alto de açúcar, **84,08%** foram classificados como alto risco.
- Nos grupos com baixo ou nenhum exercício, a proporção de alto risco foi superior a **82%**.
- A média de IMC foi **28,79** no grupo de alto risco e **22,34** no grupo de baixo risco.
- A média de idade foi **53,28 anos** no grupo de alto risco e **38,47 anos** no grupo de baixo risco.
- A média de sono foi **6,87 horas** no grupo de alto risco e **7,30 horas** no grupo de baixo risco.
- Peso e IMC apresentaram correlação positiva forte (**r = 0,78**).
- Altura e IMC apresentaram correlação negativa (**r = -0,60**).

> **Importante:** os resultados representam associações observadas na amostra. Correlação e associação não implicam causalidade.

## 📈 Visualizações

Os gráficos recomendados para a apresentação são:

1. **Distribuição do risco à saúde** — apresenta o equilíbrio da variável de interesse.
2. **Exercício × risco de saúde** — destaca a diferença entre os níveis de atividade física.
3. **Tabagismo × risco de saúde** — mostra um dos contrastes mais relevantes da análise.
4. **IMC × risco de saúde** — compara a média de IMC entre os grupos.
5. **Heatmap de correlação** — resume as relações entre as variáveis numéricas.

A escolha foi feita para manter a apresentação objetiva, evitando excesso de gráficos.

## 📁 Estrutura do projeto

```text
projeto-eda-risco-saude/
│
├── exercicio_eda_revisado.py
├── requirements.txt
├── .gitignore
├── README.md
│
└── docs/
    ├── selecao_graficos.md
    └── post_linkedin.md
```

O arquivo `dataset_saude.csv` deve ser colocado na raiz do projeto caso você queira executar o script. Como a base pode ser específica do exercício, ela não foi incluída neste pacote.

## ▶️ Como executar

Crie/ative o ambiente virtual e instale as dependências:

```bash
pip install -r requirements.txt
```

Depois execute:

```bash
python exercicio_eda_revisado.py
```

## 📌 Conclusão

A análise exploratória permitiu identificar padrões relevantes entre características demográficas, comportamentais e a classificação de risco à saúde.

O projeto demonstra o uso de Python para **carregar, validar, explorar, visualizar e interpretar dados**, servindo como exercício prático de EDA e como peça de portfólio para estudos em análise de dados.

## 👤 Autor

Projeto acadêmico desenvolvido por **Fernando**, estudante de Engenharia da Computação.
